package main.java.hr.fer.tel.rassus.humiditymicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HumidityMicroserviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
