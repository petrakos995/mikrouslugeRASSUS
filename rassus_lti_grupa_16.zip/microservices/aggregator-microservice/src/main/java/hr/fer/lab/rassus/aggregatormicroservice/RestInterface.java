package hr.fer.lab.rassus.aggregatormicroservice;

public interface RestInterface {
	Integer getCurrentReading();
}
