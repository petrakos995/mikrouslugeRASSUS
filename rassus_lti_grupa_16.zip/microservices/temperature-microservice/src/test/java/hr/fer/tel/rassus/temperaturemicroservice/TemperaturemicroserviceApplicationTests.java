package hr.fer.tel.rassus.temperaturemicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TemperaturemicroserviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
