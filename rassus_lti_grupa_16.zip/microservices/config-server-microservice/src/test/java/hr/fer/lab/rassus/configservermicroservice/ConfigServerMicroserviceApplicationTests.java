package hr.fer.lab.rassus.configservermicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigServerMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
